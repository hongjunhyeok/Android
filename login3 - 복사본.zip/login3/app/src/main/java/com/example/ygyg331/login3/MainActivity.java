package com.example.ygyg331.login3;



import java.util.HashMap;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends Activity {

    private TextView idText;
    private TextView passwordText;
    private Button btnLogout;
    public TextView tv ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



         Intent intent = getIntent();
         String userID=intent.getStringExtra("userID");
         String userPassword = intent.getStringExtra("userPassword");
         String message = "환영합니다. "+userID+"님!";

        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();



}}