package com.hardkernel.wiringpi;

//import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
//import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
//import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
//import android.os.Message;
//import android.text.Editable;
//import android.text.TextUtils;
//import android.text.TextWatcher;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.SurfaceView;
//import android.view.WindowManager;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Algorithm;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;


public class MainActivity extends AppCompatActivity implements CameraBridgeViewBase.CvCameraViewListener2 {

    public boolean first = true;
    private Mat mIntermediateMat;
    private Mat mGray;
    private Mat current;
    private Mat previous = null;
    private Mat difference;
    private int[][] pixeldata={};
    private int[] avgPixelData;

    private Button btn_capture;
    private Button btn_process;
    private Button btn_result;
    private Button btn_oneClick;
    private Button btn_user_mode;
    private Button btn_chart;

    boolean user_mode = false;

    private final static String TAG = "example-wiringPi";
    //GPIO {{{
    private ToggleButton mBtn_GPIO;
    private final int DATA_UPDATE_PERIOD = 100; // 100ms
    private final int PORT_ADC1 = 0;   // ADC.AIN0
//    private ProgressBar mPB_ADC;

    private final static int INPUT = 0;
    private final static int OUTPUT = 1;

    private final int ledPorts[] = {
            24, //214
            23, //234
            22, //219
            21, //228
            14, //230
            13, //232
            12, //235
            3,  //237
            2,  //239
            0,  //247
            7,  //249
            5,  //238
            4,  //236
            5,  //233
            6,  //231
            10, //229
            26, //224
            11, //225
            27, //218
    };




    private List<CheckBox> mLeds;
    private boolean mStopGPIO;
    private Process mProcess;

    private Handler handler = new Handler();
    Runnable mRunnableGPIO = new Runnable() {

        @Override
        public void run() {
            // TODO Auto-generated method stub
            updateGPIO();
        }
    };

//    private Handler ROIhandler = new Handler();
//    Runnable mRunnableROI = new Runnable() {
//        @Override
//        public void run() {
//            updateROI();
//        }
//    };

    //GPIO }}}

    //PWM {{{

    private ToggleButton mBtn_PWM;
    private Switch mswitch;
    private int mPWMCount = 1;
    private final String PWM_PREFIX = "/sys/devices/pwm-ctrl.";
    private final String PWM_ENABLE = "/enable";
    private final String PWM_DUTY = "/duty";
    private final String PWM_FREQ = "/freq"; //added J.
    private String mPWMEnableNode;
    private String mPWMDutyNode;
    private String mPWMFreqNode; //added J.
    //PWM }}}

    //{{{opencv

    public int getRed[],getGreen[],getBlue[], getGray[];

    TextView rgbStatus1;
    TextView rgbStatus2;
    TextView rgbStatus3;
    TextView rgbStatus4;
    TextView rgbStatus5;
    ImageView imageView;
    String folder="DCIM/Camera";
    String fileName;
    String filePath = Environment.getExternalStorageDirectory().getPath()+"/DCIM/Camera/";
    String savedFilePath;
    String[] data = new String[9999];
    String[] avergenum = new String[10];

    int k;
    private static final int CAMERA_CAPTURE = 0;
    public static int count = 0;
    int whiteValue = 0;
    int blackValue = 255;
    int red_h = 253;
    int green_h = 3;
    int blue_h = 3;
    final static int threshold = 100;


    private CameraBridgeViewBase mOpenCvCameraView;
    private Mat matInput; // Input으로 들어갈 영상이나 사진
    private Mat mByte;
    private Mat matOutput;

//
//    public native void FindFeatures(long matAddrGr, long matAddrRgba);
//
//    public native void Labling(long matAddrGr, long matAddrRgba);

    static {
        System.loadLibrary("wpi_android");
        System.loadLibrary("opencv_android");
        System.loadLibrary("opencv_java3");
    }

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS: {
                    mOpenCvCameraView.enableView();
                }
                break;
                default: {
                    super.onManagerConnected(status);
                }
                break;
            }
        }
    };
//opencv}}}


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //{{{opencv



        final OnClickListener capture_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
                String currentDateandTime = sdf.format(new Date());

                fileName = "sample_picture_" + currentDateandTime + ".png";
                String filename = "/storage/emulated/0/DCIM/Camera/samplepass.png";

                ConvertRGBtoGray(matInput.getNativeObjAddr(), matOutput.getNativeObjAddr());

//                 ConvertRGBtoGray(matInput,matResult);
                Imgcodecs.imwrite(filePath+fileName,matOutput);
                savedFilePath =filePath+fileName;
                Toast.makeText(getApplicationContext(),"captured!",Toast.LENGTH_LONG).show();

            }
        };

        // progress 할게 많아서 시간이 걸림.. 인수인계받은 대로 하긴 했으나 개선필요.
        final OnClickListener progress_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {

                    Toast.makeText(getApplicationContext(), "processing...", Toast.LENGTH_LONG).show();
                    Bitmap captureBmp = null;
                try {
                    Intent intent = new Intent(getApplicationContext(), Graph.class);

                    intent.putExtra("grayValue", getGray[0]);
                    intent.putExtra("age", 10);
                    Log.i("Main/gray:", Integer.toString(getGray[0]));

                    File file = new File(savedFilePath);
                }
                catch(Exception e){
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),"캡쳐를 진행해주세요",Toast.LENGTH_LONG).show();
                }
                try {
                    File file = new File(savedFilePath);
                    captureBmp = MediaStore.Images.Media.getBitmap(getContentResolver(),
                            Uri.fromFile(file));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                int width = captureBmp.getWidth();
                int height = captureBmp.getHeight();
                int[][] gray = new int[width][height];
                int[][] red3 = new int[width][height];
                int[][] green3 = new int[width][height];
                int[][] blue3 = new int[width][height];
                Bitmap tmpBmp = captureBmp.copy(Bitmap.Config.ARGB_8888, true);
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        //for each iterator, get RGB value of each pixels.
                        int value = captureBmp.getPixel(x, y);
                        int alpha = (value & 0xFF000000); // white.
                        int red = (value & 0x00FF0000) >> 16;  // red shift.
                        int green = (value & 0x0000FF00) >> 8; // green shift to save
                        int blue = (value & 0x000000FF);
                        double red2 = red * 0.2125;    //gray = red*0.2125 + green* 0.7154 + blue *0.07
                        double green2 = green * 0.7154;
                        double blue2 = blue * 0.0721;
                        int newRGB = (int) (red2 + green2 + blue2);///3  method to get green value.
                        int eachNewRGB = alpha | (newRGB << 16) | (newRGB << 8) | newRGB;
                        gray[x][y] = newRGB;
                        red3[x][y] = red;
                        green3[x][y] = green;
                        blue3[x][y] = blue;
                        tmpBmp.setPixel(x, y, eachNewRGB);
                    }
                }
                for (int i = 0; i < width; i++) { // �Ӱ��� ������.
                    for (int j = 0; j < height; j++) {

                        if (red_h - 3 < red3[i][j] && red3[i][j] <= red_h + 2) {// �Ӱ�ġ


                            if (green_h - 3 < green3[i][j] && green3[i][j] <= green_h + 2) {
                                if (blue_h - 3 < blue3[i][j] && blue3[i][j] <= blue_h + 2) {
                                    tmpBmp.setPixel(i, j, 0xff000000);
                                    count++;
                                }
                            }


                        } else {
                            tmpBmp.setPixel(i, j, 0xffffffff);
                        }
                    }

                }
                for (int i = 0; i < width; i++) { // �Ӱ��� ������.
                    for (int j = 0; j < height; j++) {
                        if (gray[i][j] < threshold) {// �Ӱ�ġ
                            tmpBmp.setPixel(i, j, 0xff000000);
                            count++;


                        } else {
                            tmpBmp.setPixel(i, j, 0xffffffff);
                        }
                    }
                }


                //String[] data = new String[height];
                imageView = (ImageView) findViewById(R.id.imageview);
                imageView.setImageBitmap(tmpBmp);


                int m = 0;
                int mm = 0;

                for (int k = 0; k < height; k++) {
                    data[k] = Integer.toString(0);
                }

                for (int i = 0; i < height; i++) {
                    for (int j = 0; j < width; j++) {
                        m = m + gray[j][i];//
                        mm = mm + gray[j][i];//
                    }
                    int l = m / width;//�ش� ���� gray�� �� ���� width�� ������.
                    data[i] = Integer.toString(l);//
                    m = 0;
                }
                mm = mm / (width * height);
                k = mm;



                int Max = 0, Min = 255;
                for (int i = 0; i < height; i++) {
                    if (Integer.parseInt(data[i]) > Max)
                        Max = Integer.parseInt(data[i]);//�ִ밪 ���
                    if (Integer.parseInt(data[i]) < Min)
                        Min = Integer.parseInt(data[i]);//�ּҰ� ���
                }
                int MM = Max - Min;
                MM = (int) (MM * 0.7);//�ִ밪�� �ּҰ� ���� 70%�� ����.
                System.out.println("Max - Min�� 50% : " + MM);
                //
                double wa = 0;//���� 5%�з��� ��հ�
                int HE = (int) (height * 0.05);//5%

                for (int i = 0; i < HE; i++) {
                    wa = wa + Double.parseDouble(data[i]);//���� 5%�� ��ġ�� ��
                }
                wa = wa / HE;//5% ��ġ�� ���

                int setnum = 1;//���°������ ����
                int setswitch = 0;//�׷������� �϶��κ� üũ�� ����ġ
                double setaverge = 0;//�϶��� �κ��� ��հ� ����� ���� ��
                int setcount = 0;//�϶��� �κ��� ����
                int setsw = 0;//����� �ϱ� ���� ����

                //String[] avergenum = new String[10];//�϶� �κ��� ��ġ�� ���� �׸�

                for (int i = HE; i < height; i++) {//��հ� ��� ������ ������ ���ʷ� ����

                    if (setswitch == 1)//����ġ�� 1�̸�
                    {

                        if (Double.parseDouble(data[i]) + MM > wa) {
                            //data[i]+MM�� ��հ����� Ŀ���ٸ� => �׷����� ��հ����� Ȥ�� �� �̻����� �ö󰣴ٸ�
                            setswitch = 0;//����ġ�� 0���� ����
                        } else {
                            setsw = 1;//����ϱ� ���� ����ġ�� 1�� ����
                            setaverge = setaverge + Double.parseDouble(data[i]);//setaverge�� ���� ����
                            setcount = setcount + 1;//���� ���ڵ� �Բ� ����
                        }

                    } else {

                        if (Double.parseDouble(data[i]) + MM < wa) {
                            //data[i] + MM�� ���� ���� ��հ����� ���� ���
                            // = > �׷����� �϶��ϴ� �κ��̶��
                            setswitch = 1;//����ġ�� 1�� �ٲ�.
                        }

                        if (setsw == 1) {//����ϱ� ���� ������ �����ǰ�, setswitch�� 0�̸�
                            setsw = 0;//setsw�� �ʱ�ȭ
                            int kkkk = (int) ((setaverge / setcount) + 0.5);//��� ���
                            avergenum[setnum] = Double.toString(kkkk);//�迭�� ��հ��� ����
                            System.out.println("��հ� :" + kkkk);//Ȯ�ο�
                            System.out.println("������ ���� : " + i);//Ȯ�ο�2
                            setaverge = 0;//���� ����� ���� �ʱ�ȭ
                            setcount = 0;//���� ����� ���� �ʱ�ȭ
                            setnum = setnum + 1;//���� �迭�� �ֱ����� +1
                        }

                    }
                }
            }
        };
        final OnClickListener result_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Graph.class);


                i.putExtra("Average", k);//��ü ��հ�
                i.putExtra("data", data);//�� ���� gray ��հ�.
                i.putExtra("avergenum", avergenum);//�϶��� �κ��� ��
                i.putExtra("path", savedFilePath);
                startActivity(i);

            }
        };
        final OnClickListener oneClick_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                capture_listener.onClick(v);
                progress_listener.onClick(v);
                result_listener.onClick(v);
            }
        };
        final OnClickListener usermode_listener =new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        };

        final OnClickListener graph_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"processing...",Toast.LENGTH_LONG).show();
                try{
                Intent chartIntent = new Intent(getApplication(),chart.class);
                chartIntent.putExtra("avgpixel",avgPixelData);

                startActivity(chartIntent);
            }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        };

        btn_capture =(Button)findViewById(R.id.btn_capture);
        btn_process=(Button)findViewById(R.id.btn_process);
        btn_result=(Button)findViewById(R.id.btn_result);
        btn_oneClick=(Button)findViewById(R.id.btn_oneClick);
        btn_user_mode=(Button)findViewById(R.id.btn_user_mode);
        btn_chart=(Button)findViewById(R.id.btn_graph);
        Intent user_mode_info =getIntent();
        user_mode=user_mode_info.getBooleanExtra("isAdmin",false);
        if(!user_mode) {
            btn_capture.setEnabled(user_mode);
            btn_capture.setVisibility(View.GONE);
            btn_process.setEnabled(user_mode);
            btn_process.setVisibility(View.GONE);
            btn_result.setEnabled(user_mode);
            btn_result.setVisibility(View.GONE);
            btn_oneClick.setEnabled(!user_mode);

        }else{
            btn_capture.setEnabled(user_mode);
            btn_process.setEnabled(user_mode);
            btn_result.setEnabled(user_mode);
            btn_oneClick.setEnabled(user_mode);
        }

        btn_capture.setOnClickListener(capture_listener);
        btn_process.setOnClickListener(progress_listener);
        btn_result.setOnClickListener(result_listener);
        btn_oneClick.setOnClickListener(oneClick_listener);
        btn_user_mode.setOnClickListener(usermode_listener);
        btn_chart.setOnClickListener(graph_listener);
      //opencv}}}

        //GPIO {{{
        mBtn_GPIO = (ToggleButton) findViewById(R.id.btn_gpio);
        mBtn_GPIO.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // TODO Auto-generated method stub
                if (isChecked) {

                    wiringPiSetup();

                    for (int i = 0; i < ledPorts.length; i++)
                        pinMode(ledPorts[i], OUTPUT);


                } else {
                    for (int i = 0; i < ledPorts.length; i++)
                        pinMode(ledPorts[i], 0);

                }
            }
        });

        try {
            mProcess = Runtime.getRuntime().exec("su");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //GPIO }}}

        //PWM {{{
        mswitch=(Switch)findViewById(R.id.switch1);
        mswitch.setEnabled(false);
        mswitch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setEnalbePWM(1, true);

                if(isChecked) {
                    setFreqPWM(0, 100);
                    setDuty(0, 1000); //200부터 동작 (나옴)
                }
                else{
                    setFreqPWM(0,100);
                    setDuty(0, 100); //100부터 동작 (들어감)
                }

            }
        });


        for (int i = 0; i < 100; i++) {
            File f = new File(PWM_PREFIX + i);
            if (f.isDirectory()) {
                mPWMEnableNode = PWM_PREFIX + i + PWM_ENABLE;
                Log.e(TAG, "pwm enable : " + mPWMEnableNode);
                mPWMDutyNode = PWM_PREFIX + i + PWM_DUTY;
                Log.e(TAG, "pwm duty : " + mPWMDutyNode);
                mPWMFreqNode = PWM_PREFIX + i + PWM_FREQ; //added J.
                break;
            }
        }





        mBtn_PWM = (ToggleButton) findViewById(R.id.btn_pwm);
        mBtn_PWM.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // TODO Auto-generated method stub
                if (isChecked) {
                    insmodPWM();
                    setEnalbePWM(0,isChecked);
                    setFreqPWM(0,100);
//                    setDuty(0,1000);
                    mswitch.setEnabled(true);
                    mswitch.setChecked(false);


                } else {

                    mswitch.setEnabled(false);
                    mswitch.setChecked(false);


                    rmmodPWM();
                }
            }
        });
        mBtn_PWM.setChecked(false);

        //PWM }}}


        //{{{opencv
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //퍼미션 상태 확인
            if (!hasPermissions(PERMISSIONS)) {

                //퍼미션 허가 안되어있다면 사용자에게 요청
                requestPermissions(PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
        }

        mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.activity_surface_view);
        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
        mOpenCvCameraView.setCvCameraViewListener(this);
        mOpenCvCameraView.setCameraIndex(0); // front-camera(1),  back-camera(0)
        mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
    }
    //opencv}}}
    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        //{{{opencv
        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "onResume :: Internal OpenCV library not found.");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_2_0, this, mLoaderCallback);
        } else {
            Log.d(TAG, "onResum :: OpenCV library found inside package. Using it!");
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
        //opencv}}}
    }
    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();

        //GPIO {{{
        mBtn_GPIO.setChecked(false);
        //GPIO }}}
        //PWM {{{
        mBtn_PWM.setChecked(false);
        //PWM }}}
//{{opencv
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
        //opencv}}}
    }

    //{{opencv
    public void onDestroy() {
        super.onDestroy();

        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }


    @Override
    public void onCameraViewStarted(int width, int height) {
        matInput = new Mat(height, width, CvType.CV_8UC4);
        matOutput = new Mat(height,width,CvType.CV_8UC4);

        mByte= new Mat(height,width,CvType.CV_8SC4);
        mIntermediateMat = new Mat(height, width, CvType.CV_8UC4);
        mGray = new Mat(height, width, CvType.CV_8UC1);
        previous = new Mat(width, height, CvType.CV_64FC4);        //차프레임 구할때 쓰는 프레임 RESULT BUTTON
        current = new Mat(width, height, CvType.CV_64FC4);         //차프레임 구할때 쓰는 프레임 RESULT BUTTON
        difference = new Mat(width, height, CvType.CV_64FC4);
    }

    @Override
    public void onCameraViewStopped() {
        matInput.release();
        mGray.release();
        mIntermediateMat.release();
        current.release();
        previous.release();
        difference.release();
    }

    private int scale = 10;
    private int[] red = new int[scale];
    private int[] green = new int[scale];
    private int[] blue = new int[scale];
    private int[] gray = new int[scale];
    int startX = 0;
    int startY = 120;
    int Roi_height=20;
    int Roi_width=400;

    @Override
    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {
//{{{roi
        // test용
//        rgbStatus1 = (TextView) findViewById(R.id.ROI1);
//        rgbStatus2 = (TextView) findViewById(R.id.ROI2);
//        rgbStatus3 = (TextView) findViewById(R.id.ROI3);
//        rgbStatus4 = (TextView) findViewById(R.id.ROI4);
//        rgbStatus5 = (TextView) findViewById(R.id.ROI5);

        //roi 색 설정
        Scalar color = new Scalar(255, 0, 0);
//        int distance = 40; //roi간의 간격

        //roi 시작 좌표, X,Y의 전체 크기는 아래서 구함.

        //test용 roibars
        Rect[] roibars = new Rect[scale];

        //Roi 영역설정. startX , Y = 시작 위치 너비와 높이 설정.
        //Roi 영역이 화면 밖으로 넘어가게 되면 에러발생하면서 어플이 죽으니 주의.
        Rect Roi= new Rect(startX,startY,Roi_width,Roi_height);

        //test용.
        int[][] avgRGB = new int[scale][4];

        //roi data 관련 함수들 모아놓은 클래스 객체화.
        roiDataExtract roiData= new roiDataExtract();

        //pixeldata = Roi영역의 각 픽셀에 해당하는 rgb값
        pixeldata=roiData.getPixeldata(Roi,matInput);

        //avgPixelData = 그래프로 표시하기 위해 height 평균시킴.
        avgPixelData=new int[400];
        avgPixelData=roiData.AvgPixeldata(Roi,pixeldata);

        //test
//        for(int i=0;i<400;i++)
//        Log.i("data "+i+ ":",Integer.toString(avgPixelData[i]));

//        for (int i = 0; i < scale; i++) {
//            roi 만듬
//            roibars[i] = new Rect(startX + (i * distance), startY, width, height);
//        }
//        int threshold = 10;
//        int count = 0;


        try {

            matInput = inputFrame.rgba();
//
//            for (int i = 0; i < scale; i++)
//                for (int j = 0; j < 4; j++)
//                    avgRGB[i][j] = calcRGB(roibars[i])[j];
//

            //화면의 크기는 layout에서 설정한 것에 따라 다르므로 Log창에서 너비와 높이를 확인해야한다.
//            Log.i("MatInput height: ",Integer.toString(matInput.height()));
//            Log.i("MatInput width: ",Integer.toString(matInput.width()));

        }catch (Exception e){
            e.printStackTrace();
        }
        if (first) {
            int[] temp_red = roiData.Getcol(avgRGB, 0);
            int[] temp_green = roiData.Getcol(avgRGB, 1);
            int[] temp_blue = roiData.Getcol(avgRGB, 2);
            int[] temp_gray = roiData.Getcol(avgRGB, 3);
            for (int i = 0; i < scale; i++) {
                gray[i] = temp_gray[i];
                red[i] = temp_red[i];
                green[i] = temp_green[i];
                blue[i] = temp_blue[i];
            }
            first = false;
            return matInput;
        }

        int[] temp_gray = roiData.Getcol(avgRGB, 3);
        final int[] temp_red = roiData.Getcol(avgRGB, 0);
        int[] temp_green = roiData.Getcol(avgRGB, 1);
        int[] temp_blue = roiData.Getcol(avgRGB, 2);  //기준값 저장 이후 프레임의 gray값

        getRed=temp_red;
        getGreen=temp_green;
        getBlue=temp_blue;
        getGray =temp_gray;

        Imgproc.rectangle(matInput, new Point(0, 110), new Point(432, 130), color, 1); //test용으로 출력 (지우면 처리속도 증가)

//        for (int i = 0; i < scale; i++) {
//                    temp_grey[i] = Math.abs(gray[i] - temp_grey[i]); //기준값 대비 차이
//            Imgproc.rectangle(matInput, new Point(20+roibars[i].x, 110), new Point(roibars[i].x + width, 130), color, 0); //test용으로 출력 (지우면 처리속도 증가)
//            Imgproc.putText(matInput, new String("r" + temp_red[i] + " "), new Point(roibars[i].x, roibars[i].y - 80 + 200 * (i % 2)), 1, 2, color, 2);
//            rgbStatus1.setText(r1);
//
//            ROIhandler.postDelayed(mRunnableROI,100);
//
//
//        matResult= new Mat(matInput.rows(),matInput.cols(),matInput.type());

        return matInput;


//        ConvertRGBtoGray(matInput.getNativeObjAddr(), matResult.getNativeObjAddr());
//        Labling(matInput.getNativeObjAddr(),matResult.getNativeObjAddr());
//        return matResult;
//        public native void Labling(long matAddrGr, long matAddrRgba);
    }



    //roi}}}
    //여기서부턴 퍼미션 관련 메소드
    static final int PERMISSIONS_REQUEST_CODE = 1000;
    String[] PERMISSIONS  = {"android.permission.CAMERA",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.INTERNET"};


    private boolean hasPermissions(String[] permissions) {
        int result;

        //스트링 배열에 있는 퍼미션들의 허가 상태 여부 확인
        for (String perms : permissions){

            result = ContextCompat.checkSelfPermission(this, perms);

            if (result == PackageManager.PERMISSION_DENIED){
                //허가 안된 퍼미션 발견
                return false;
            }
        }

        //모든 퍼미션이 허가되었음
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch(requestCode){

            case PERMISSIONS_REQUEST_CODE:
                if (grantResults.length > 0) {
                    boolean cameraPermissionAccepted = grantResults[0]
                            == PackageManager.PERMISSION_GRANTED;

                    if (!cameraPermissionAccepted)
                        showDialogForPermission("앱을 실행하려면 퍼미션을 허가하셔야합니다.");
                }
                break;
        }
    }
    @TargetApi(Build.VERSION_CODES.M)
    private void showDialogForPermission(String msg) {

        AlertDialog.Builder builder = new AlertDialog.Builder( MainActivity.this);
        builder.setTitle("알림");
        builder.setMessage(msg);
        builder.setCancelable(false);
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id){
                requestPermissions(PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                finish();
            }
        });
        builder.create().show();
    }
    //opencv}}}


    //GPIO {{{
    public void updateGPIO() {
        int i = 0;
        int ledPos = 0;
        int adcValue = analogRead(PORT_ADC1);
        //Log.e(TAG, "updateGPIO adcValue = " + adcValue);

        //added J.
        //eleminated the hopping of checked checkboxes
        if (adcValue < 0) adcValue = 0;
        if (adcValue > 0) {
        ledPos = adcValue * ledPorts.length / 1024;
        ledPos = (ledPorts.length - (ledPos / 1000));
            for (i = 0; i < ledPorts.length; i++) {
                digitalWrite (ledPorts[i], 0);
//                mLeds.get(i).setChecked(false);
            }

            for (i = 0; i < ledPos; i++) {
                digitalWrite (ledPorts[i], 1);
//                mLeds.get(i).setChecked(true);
            }
        if (!mStopGPIO)
            handler.postDelayed(mRunnableGPIO, 100);
    }}


    //GPIO }}}

    //PWM {{{
    private void insmodPWM() {
        try {
            DataOutputStream os = new DataOutputStream(mProcess.getOutputStream());

            os.writeBytes("insmod /system/lib/modules/pwm-meson.ko\n");
            os.writeBytes("insmod /system/lib/modules/pwm-ctrl.ko\n");
            os.flush();
            Thread.sleep(100);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void rmmodPWM() {
        try {
            DataOutputStream os = new DataOutputStream(mProcess.getOutputStream());
            os.writeBytes("rmmod pwm_ctrl\n");
            os.writeBytes("rmmod pwm_meson\n");
            os.flush();
            Thread.sleep(100);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void setEnalbePWM(int index, boolean enable) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(mPWMEnableNode + index));
            if (enable)
                bw.write("1");
            else
                bw.write("0");
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        //added J.
        //need to set the frequency
    private void setFreqPWM(int index,int value){
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(mPWMFreqNode + index));
            bw.write(Integer.toString(value));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setDuty(int index, int duty) {
        try {
            //                mPWMDutyNode = PWM_PREFIX + i + PWM_DUTY;
            // /sys/devices/pwm-ctrl.43/duty
            BufferedWriter bw = new BufferedWriter(new FileWriter(mPWMDutyNode + index));
            bw.write(Integer.toString(duty));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //PWM }}}
    //{{{opencv
//    public void updateROI(){
//
//        String red1= String.valueOf(getRed[0]);
//        String red2= String.valueOf(getRed[1]);
//        String red3= String.valueOf(getRed[2]);
//        String red4= String.valueOf(getRed[3]);
//        String red5= String.valueOf(getRed[4]);
//
//        String green1=String.valueOf(getGreen[0]);
//        String green2=String.valueOf(getGreen[1]);
//        String green3=String.valueOf(getGreen[2]);
//        String green4=String.valueOf(getGreen[3]);
//        String green5=String.valueOf(getGreen[4]);
//
//        String blue1=String.valueOf(getBlue[0]);
//        String blue2=String.valueOf(getBlue[1]);
//        String blue3=String.valueOf(getBlue[2]);
//        String blue4=String.valueOf(getBlue[3]);
//        String blue5=String.valueOf(getBlue[4]);
//
//        rgbStatus1.setText("red :"+red1+" green :"+green1+" blue :"+blue1);
//        rgbStatus2.setText("red :"+red2+" green :"+green2+" blue :"+blue2);
//        rgbStatus3.setText("red :"+red3+" green :"+green3+" blue :"+blue3);
//        rgbStatus4.setText("red :"+red4+" green :"+green4+" blue :"+blue4);
//        rgbStatus5.setText("red :"+red5+" green :"+green5+" blue :"+blue5);
//    }

    //opencv}}}

    public native int wiringPiSetup();
    //    public native int wiringPiSetupSys();
    public native int analogRead(int port);
    public native void digitalWrite(int port, int onoff);
    public native void pinMode(int port, int value);
    public native void ConvertRGBtoGray(long matAddrInput, long matAddrResult);

}