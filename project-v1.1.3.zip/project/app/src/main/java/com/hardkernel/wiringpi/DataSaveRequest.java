package com.hardkernel.wiringpi;

import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ygyg331 on 2018-05-19.
 */

public class DataSaveRequest extends StringRequest {

    final static private String URL = "http://ygyg331.cafe24.com/camera.php";
    private Map<String, String> parameters;

    public DataSaveRequest(String userTime,  String userResult,String userName, int userData, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);
        parameters = new HashMap<>();
        parameters.put("userTime", userTime);
        parameters.put("userResult",userResult);
        parameters.put("userName", userName);
        parameters.put("userData",userData+"");
//        parameters.put("grayData1", 3 + "");
//        parameters.put("grayData2", 3 + "");
//        parameters.put("grayData3", 3 + "");
//        parameters.put("grayData4", 3 + "");
//        parameters.put("grayData5", 3 + "");
        Log.i("Request/Time",userTime);
        Log.i("Request/Result",userResult);
        Log.i("Request/Name",userName);
        Log.i("Request/Data",Integer.toString(userData));


        //int형이므로 ""를 붙여야함

    }

    @Override
    public Map<String, String> getParams() {
        return parameters;
    }
}