package com.hardkernel.wiringpi;

import android.app.Activity;
import android.content.Intent;

import org.opencv.core.Mat;
import org.opencv.core.Rect;

/**
 * Created by ygyg331 on 2018-06-28.
 */

public class roiDataExtract {
    public int[][] getPixeldata(Rect Roi, Mat matInput){
        int avg1=0,avg2=0,avg3=0,avg4=0;
        int pixels[][]=new int[Roi.width][Roi.height];

        for(int i = Roi.x; i< Roi.x+Roi.width ;i++)
            for(int j = Roi.y; j<Roi.y+Roi.height;j++)
            {
                double[] rgbV = matInput.get(j, i);
                avg1 = (int)( (rgbV[0]+rgbV[1]+rgbV[2])/3);
                pixels[i-Roi.x][j-Roi.y]=avg1;
            }
        return pixels;
    }

    public int[] AvgPixeldata(Rect Roi,int[][] pixels){
        int sum=0;
        int avgPixelData[]=new int[Roi.width];
        for(int i=0;i<Roi.width;i++){
            for(int j=0;j<Roi.height;j++){
                sum += pixels[i][j];

            }
            avgPixelData[i]=sum/Roi.height;
            sum=0;
        }
        return avgPixelData;
    }

    public int[] calcRGB(Rect Roi,Mat matInput)   //Roi를 전달받아서 RGB Gray 평균값을 계산하고 배열을 리턴 [R G B Gray]
    {
        int avg1=0,avg2=0,avg3=0,avg4=0;

        for(int i = Roi.x; i< Roi.x+Roi.width ;i++)
            for(int j = Roi.y; j<Roi.y+Roi.height;j++)
            {
                double[] rgbV = matInput.get(j, i);
                avg1 += rgbV[0] ;
                avg2 += rgbV[1] ;
                avg3 += rgbV[2] ;
            }
        avg1 /= (Roi.width * Roi.height) ;    //RED
        avg2 /= (Roi.width * Roi.height) ;    //Green
        avg3 /= (Roi.width * Roi.height) ;    //BLUE
        avg4 = (avg1+avg2+avg3)/3;

        int arr[] = {avg1,avg2,avg3,avg4}; //RED,Green,Blue,Gray

        return arr;
    }
    public int[] Getcol(int[][] arr, int col) //2차원 배열에서 특정 열을 1차원 배열로 리턴
    {
        int length = arr.length;
        int[] arr1 = new int[length];

        for(int i=0;i<length;i++)
            arr1[i] = arr[i][col];

        return arr1;

    }

    //test
//    public int smallestFromData(int[] Data,int from,int to){
//        int smallest=255;
//        for(int i=from;i<to;i++)
//        {
//            if(smallest>Data[i]) smallest=Data[i];
//        }
//        return smallest;
//    }
//    public int[] peak(int[] Data,int from,int to){
//        int max= Roi_width/10;
//        int peakdata[]=new int[max];
//
//        // 10으로 나눈 후, 각 구역에 대한 최소값 반환
//        for(int i=0;i<max;i++){
//            peakdata[i]=smallestFromData(Data,(i*10),(i+1)*10);
//        }
//
//        return peakdata;
//    }
}
