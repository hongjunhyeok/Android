package com.hardkernel.wiringpi.Login_Register;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.hardkernel.wiringpi.DBRequest.LoginRequest;
import com.hardkernel.wiringpi.MainActivity;
import com.hardkernel.wiringpi.R;

import org.json.JSONObject;


public class LoginActivity extends Activity {
    private static final String TAG = RegisterActivity.class.getSimpleName();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText idText = (EditText) findViewById(R.id.id);
        final EditText passwordText = (EditText) findViewById(R.id.password);
        final Button btnLogin = (Button) findViewById(R.id.btnLogin);
        final Button btnJoin = (Button) findViewById(R.id.btnJoin);

        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(LoginActivity.this,RegisterActivity.class);
                LoginActivity.this.startActivity(registerIntent);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String userID = idText.getText().toString();
                final String userPassword = passwordText.getText().toString();
                //내부 클래스로써, 인터넷에 접속한뒤에 response가 건너오면 그것을 저장할수있게 해줌
                Response.Listener<String> responseListener = new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONObject jsonResponse = new JSONObject(response);//response 저장.
                            boolean success = jsonResponse.getBoolean("success");
                            Log.i("success :" , Boolean.toString(success));
                            // success > 변수인데 success의 값은 true로 반환했었음
                            if(success){
                                String userID = jsonResponse.getString("userID");
                                String userPassword = jsonResponse.getString("userPassword");
                                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                                intent.putExtra("userID",userID);
                                intent.putExtra("isAdmin",true);
                                LoginActivity.this.startActivity(intent);

                            }
                            else{
                                String why = Boolean.toString(success);
                                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                                builder.setMessage("로그인에 실패하였습니다. : why ?"+why)
                                        .setNegativeButton("다시시도",null)
                                        .create().show();

                            }
                        }catch (Exception e){
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),"fail",Toast.LENGTH_SHORT).show();

                        }
                    }
                };
                //로그인 리퀘스트는 response를 받아온다.
                LoginRequest loginRequest= new LoginRequest(userID,userPassword,responseListener);
                RequestQueue queue = Volley.newRequestQueue(LoginActivity.this); //접속해서 request를 보내고 response를 받아옴.
                queue.add(loginRequest);

            }
        });




    }
}