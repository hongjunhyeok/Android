package com.hardkernel.wiringpi;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.SurfaceView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.hardkernel.wiringpi.Chart_Graph.Graph;
import com.hardkernel.wiringpi.Chart_Graph.chart;
import com.hardkernel.wiringpi.Chart_Graph.roiDataExtract;
import com.hardkernel.wiringpi.DBRequest.DataSaveRequest;
import com.hardkernel.wiringpi.GPIO.GpioControl;
import com.hardkernel.wiringpi.Login_Register.LoginActivity;

import org.json.JSONException;
import org.json.JSONObject;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;


public class MainActivity extends AppCompatActivity implements CameraBridgeViewBase.CvCameraViewListener2 {

    public boolean first = true;
    private Mat mIntermediateMat;
    private Mat mGray;
    private Mat current;
    private Mat previous = null;
    private Mat difference;
    private int[] avgPixelData;
    boolean user_mode = false;
    private final static String TAG = "example-wiringPi";

    static {
        System.loadLibrary("wpi_android");
        System.loadLibrary("opencv_android");
        System.loadLibrary("opencv_java3");
    }


    //LED {{{
    private ToggleButton mBtn_GPIO;
    private final static int INPUT = 0;
    private final static int OUTPUT = 1;

    //26번 포트이나 GPIO상에선 32번 핀임 추가하고싶으면 이전버전 참고. 2018.07.16 수정.홍준혁
    private final int ledPorts[] = { 26 };

//    private Handler handler = new Handler();
//    Runnable mRunnableGPIO = new Runnable() {
//
//        @Override
//        public void run() {
//            // TODO Auto-generated method stub
//            updateGPIO();
//        }
//    };

    private Handler ROIhandler = new Handler();
    Runnable mRunnableROI = new Runnable() {
        @Override
        public void run() {
            Roi_update();

        }
    };

    //LED }}}

    //PWM {{{

    private ToggleButton mBtn_PWM;
    private Switch mswitch;
    Process mProcess;
    String mPWMEnableNode;
    String mPWMDutyNode;
    String mPWMFreqNode; //added J.

    //PWM }}}

    //{{{opencv
    TextView tv1;
    TextView tv2;
    TextView tv3;
    TextView tv4;
    TextView tv5;
    TextView tv6;
    TextView tv7;
    TextView tv8;
    TextView tv9;
    TextView tv10;




    ImageView imageView;
    //String folder="DCIM/Camera";
    String fileName;
    String filePath = Environment.getExternalStorageDirectory().getPath()+"/DCIM/Camera/";
    String savedFilePath;
    String[] data = new String[9999];
    String[] avergenum = new String[10];

    int k;
    private CameraBridgeViewBase mOpenCvCameraView;
    private Mat matInput; // Input으로 들어갈 영상이나 사진
    private Mat matOutput;

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS: {
                    mOpenCvCameraView.enableView();
                }
                break;
                default: {
                    super.onManagerConnected(status);
                }
                break;
            }
        }
    };
//opencv}}}


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //{{{opencv



        final OnClickListener capture_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");

                String currentDateandTime = sdf.format(new Date());
            }


        };
        final OnClickListener send_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"ok22",Toast.LENGTH_LONG).show();

                //time
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.KOREA);
                final String userTime = sdf.format(new Date());
                //name
                String myname="JH" ;
                final String userResult = "POSITIVE";
                int userData = avgPixelData[100];

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            Log.i("success :" , Boolean.toString(success));
                            if (success) {
                                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("성공적으로 저장하였습니다.")
                                        .setPositiveButton("확인", null)
                                        .create()
                                        .show();
                            } else {
                                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("저장에 실패하였습니다.")
                                        .setNegativeButton("확인", null)
                                        .create()
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.i("success11 :" , String.valueOf(e));
                        }
                    }
                };
                DataSaveRequest dataSaveRequest = new DataSaveRequest(userTime, userResult, myname, userData, responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(dataSaveRequest);
                Log.i("graph/Time",userTime);
                Log.i("graph/Result",userResult);
                Log.i("graph/Name",myname);
                Log.i("graph/Data",Integer.toString(userData));


            }
        };
        // progress 할게 많아서 시간이 걸림.. 인수인계받은 대로 하긴 했으나 개선필요.
        final OnClickListener progress_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
//
//                    Toast.makeText(getApplicationContext(), "processing...", Toast.LENGTH_LONG).show();
//                    Bitmap captureBmp = null;
//                try {
//                    Intent intent = new Intent(getApplicationContext(), Graph.class);
//
//                    intent.putExtra("grayValue", getGray[0]);
//                    intent.putExtra("age", 10);
//                    Log.i("Main/gray:", Integer.toString(getGray[0]));
//
//                    File file = new File(savedFilePath);
//                }
//                catch(Exception e){
//                    e.printStackTrace();
//                    Toast.makeText(getApplicationContext(),"캡쳐를 진행해주세요",Toast.LENGTH_LONG).show();
//                }
//                try {
//                    File file = new File(savedFilePath);
//                    captureBmp = MediaStore.Images.Media.getBitmap(getContentResolver(),
//                            Uri.fromFile(file));
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//                int width = captureBmp.getWidth();
//                int height = captureBmp.getHeight();
//                int[][] gray = new int[width][height];
//                int[][] red3 = new int[width][height];
//                int[][] green3 = new int[width][height];
//                int[][] blue3 = new int[width][height];
//                Bitmap tmpBmp = captureBmp.copy(Bitmap.Config.ARGB_8888, true);
//                for (int y = 0; y < height; y++) {
//                    for (int x = 0; x < width; x++) {
//                        //for each iterator, get RGB value of each pixels.
//                        int value = captureBmp.getPixel(x, y);
//                        int alpha = (value & 0xFF000000); // white.
//                        int red = (value & 0x00FF0000) >> 16;  // red shift.
//                        int green = (value & 0x0000FF00) >> 8; // green shift to save
//                        int blue = (value & 0x000000FF);
//                        double red2 = red * 0.2125;    //gray = red*0.2125 + green* 0.7154 + blue *0.07
//                        double green2 = green * 0.7154;
//                        double blue2 = blue * 0.0721;
//                        int newRGB = (int) (red2 + green2 + blue2);///3  method to get green value.
//                        int eachNewRGB = alpha | (newRGB << 16) | (newRGB << 8) | newRGB;
//                        gray[x][y] = newRGB;
//                        red3[x][y] = red;
//                        green3[x][y] = green;
//                        blue3[x][y] = blue;
//                        tmpBmp.setPixel(x, y, eachNewRGB);
//                    }
//                }
//                for (int i = 0; i < width; i++) { // �Ӱ��� ������.
//                    for (int j = 0; j < height; j++) {
//
//                        if (red_h - 3 < red3[i][j] && red3[i][j] <= red_h + 2) {// �Ӱ�ġ
//
//
//                            if (green_h - 3 < green3[i][j] && green3[i][j] <= green_h + 2) {
//                                if (blue_h - 3 < blue3[i][j] && blue3[i][j] <= blue_h + 2) {
//                                    tmpBmp.setPixel(i, j, 0xff000000);
//                                    count++;
//                                }
//                            }
//
//
//                        } else {
//                            tmpBmp.setPixel(i, j, 0xffffffff);
//                        }
//                    }
//
//                }
//                for (int i = 0; i < width; i++) { // �Ӱ��� ������.
//                    for (int j = 0; j < height; j++) {
//                        if (gray[i][j] < threshold) {// �Ӱ�ġ
//                            tmpBmp.setPixel(i, j, 0xff000000);
//                            count++;
//
//
//                        } else {
//                            tmpBmp.setPixel(i, j, 0xffffffff);
//                        }
//                    }
//                }
//
//
//                //String[] data = new String[height];
//                imageView = (ImageView) findViewById(R.id.imageview);
//                imageView.setImageBitmap(tmpBmp);
//
//
//                int m = 0;
//                int mm = 0;
//
//                for (int k = 0; k < height; k++) {
//                    data[k] = Integer.toString(0);
//                }
//
//                for (int i = 0; i < height; i++) {
//                    for (int j = 0; j < width; j++) {
//                        m = m + gray[j][i];//
//                        mm = mm + gray[j][i];//
//                    }
//                    int l = m / width;//�ش� ���� gray�� �� ���� width�� ������.
//                    data[i] = Integer.toString(l);//
//                    m = 0;
//                }
//                mm = mm / (width * height);
//                k = mm;
//
//
//
//                int Max = 0, Min = 255;
//                for (int i = 0; i < height; i++) {
//                    if (Integer.parseInt(data[i]) > Max)
//                        Max = Integer.parseInt(data[i]);//�ִ밪 ���
//                    if (Integer.parseInt(data[i]) < Min)
//                        Min = Integer.parseInt(data[i]);//�ּҰ� ���
//                }
//                int MM = Max - Min;
//                MM = (int) (MM * 0.7);//�ִ밪�� �ּҰ� ���� 70%�� ����.
//                System.out.println("Max - Min�� 50% : " + MM);
//                //
//                double wa = 0;//���� 5%�з��� ��հ�
//                int HE = (int) (height * 0.05);//5%
//
//                for (int i = 0; i < HE; i++) {
//                    wa = wa + Double.parseDouble(data[i]);//���� 5%�� ��ġ�� ��
//                }
//                wa = wa / HE;//5% ��ġ�� ���
//
//                int setnum = 1;//���°������ ����
//                int setswitch = 0;//�׷������� �϶��κ� üũ�� ����ġ
//                double setaverge = 0;//�϶��� �κ��� ��հ� ����� ���� ��
//                int setcount = 0;//�϶��� �κ��� ����
//                int setsw = 0;//����� �ϱ� ���� ����
//
//                //String[] avergenum = new String[10];//�϶� �κ��� ��ġ�� ���� �׸�
//
//                for (int i = HE; i < height; i++) {//��հ� ��� ������ ������ ���ʷ� ����
//
//                    if (setswitch == 1)//����ġ�� 1�̸�
//                    {
//
//                        if (Double.parseDouble(data[i]) + MM > wa) {
//                            //data[i]+MM�� ��հ����� Ŀ���ٸ� => �׷����� ��հ����� Ȥ�� �� �̻����� �ö󰣴ٸ�
//                            setswitch = 0;//����ġ�� 0���� ����
//                        } else {
//                            setsw = 1;//����ϱ� ���� ����ġ�� 1�� ����
//                            setaverge = setaverge + Double.parseDouble(data[i]);//setaverge�� ���� ����
//                            setcount = setcount + 1;//���� ���ڵ� �Բ� ����
//                        }
//
//                    } else {
//
//                        if (Double.parseDouble(data[i]) + MM < wa) {
//                            //data[i] + MM�� ���� ���� ��հ����� ���� ���
//                            // = > �׷����� �϶��ϴ� �κ��̶��
//                            setswitch = 1;//����ġ�� 1�� �ٲ�.
//                        }
//
//                        if (setsw == 1) {//����ϱ� ���� ������ �����ǰ�, setswitch�� 0�̸�
//                            setsw = 0;//setsw�� �ʱ�ȭ
//                            int kkkk = (int) ((setaverge / setcount) + 0.5);//��� ���
//                            avergenum[setnum] = Double.toString(kkkk);//�迭�� ��հ��� ����
//                            System.out.println("��հ� :" + kkkk);//Ȯ�ο�
//                            System.out.println("������ ���� : " + i);//Ȯ�ο�2
//                            setaverge = 0;//���� ����� ���� �ʱ�ȭ
//                            setcount = 0;//���� ����� ���� �ʱ�ȭ
//                            setnum = setnum + 1;//���� �迭�� �ֱ����� +1
//                        }
//
//                    }
//                }
            }
        };
        final OnClickListener result_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Graph.class);


                i.putExtra("Average", k);
                i.putExtra("data", avgPixelData);
                i.putExtra("avergenum", avergenum);
                i.putExtra("path", savedFilePath);
                startActivity(i);

            }
        };
        final OnClickListener oneClick_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                capture_listener.onClick(v);
                progress_listener.onClick(v);
                result_listener.onClick(v);
            }
        };
        final OnClickListener usermode_listener =new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        };

        final OnClickListener graph_listener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"processing...",Toast.LENGTH_LONG).show();
                try{
                Intent chartIntent = new Intent(getApplication(),chart.class);
                chartIntent.putExtra("avgpixel",avgPixelData);

                startActivity(chartIntent);
            }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        };

        Button btn_capture;
        Button btn_send;
        Button btn_process;
        Button btn_result;
        Button btn_oneClick;
        Button btn_user_mode;
        Button btn_chart;

        btn_capture =findViewById(R.id.btn_capture);
        btn_send=findViewById(R.id.btn_send);
        btn_process=findViewById(R.id.btn_process);
        btn_result=findViewById(R.id.btn_result);
        btn_oneClick=findViewById(R.id.btn_oneClick);
        btn_user_mode=findViewById(R.id.btn_user_mode);
        btn_chart=findViewById(R.id.btn_graph);
        Intent user_mode_info =getIntent();
        user_mode=user_mode_info.getBooleanExtra("isAdmin",false);
        if(!user_mode) {
            btn_capture.setEnabled(false);
            btn_capture.setVisibility(View.GONE);
            btn_process.setEnabled(user_mode);
            btn_process.setVisibility(View.GONE);
            btn_result.setEnabled(user_mode);
            btn_result.setVisibility(View.GONE);
            btn_oneClick.setEnabled(!user_mode);

        }else{
            btn_capture.setEnabled(true);
            btn_process.setEnabled(user_mode);
            btn_result.setEnabled(user_mode);
            btn_oneClick.setEnabled(user_mode);
        }

        btn_capture.setOnClickListener(capture_listener);
        btn_send.setOnClickListener(send_listener);
        btn_process.setOnClickListener(progress_listener);
        btn_result.setOnClickListener(result_listener);
        btn_oneClick.setOnClickListener(oneClick_listener);
        btn_user_mode.setOnClickListener(usermode_listener);
        btn_chart.setOnClickListener(graph_listener);

      //opencv}}}

        //GPIO {{{
        mBtn_GPIO = findViewById(R.id.btn_gpio);
        mBtn_GPIO.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // TODO Auto-generated method stub
                if (isChecked) {

                    wiringPiSetup();

                    for (int i = 0; i < ledPorts.length; i++)
                        pinMode(ledPorts[i], OUTPUT);

                } else {
                    for (int i = 0; i < ledPorts.length; i++)
                        pinMode(ledPorts[i], INPUT);

                }
            }
        });

        //GPIO }}}

        //PWM {{{

        final String PWM_PREFIX = "/sys/devices/pwm-ctrl.";
        final String PWM_ENABLE = "/enable";
        final String PWM_DUTY = "/duty";
        final String PWM_FREQ = "/freq"; //added J.

        for (int i = 0; i < 100; i++) {
            File f = new File(PWM_PREFIX + i);
            if (f.isDirectory()) {
                mPWMEnableNode = PWM_PREFIX + i + PWM_ENABLE;
                Log.e(TAG, "pwm enable : " + mPWMEnableNode);
                mPWMDutyNode = PWM_PREFIX + i + PWM_DUTY;
                Log.e(TAG, "pwm duty : " + mPWMDutyNode);
                mPWMFreqNode = PWM_PREFIX + i + PWM_FREQ; //added J.
                break;
            }
        }
        mBtn_PWM = findViewById(R.id.btn_pwm);
        mBtn_PWM.setEnabled(true);
        final GpioControl mGpioControl = new GpioControl();
        mGpioControl.init();
        mBtn_PWM.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mGpioControl.insmodPWM();

                if(isChecked) {
                    mGpioControl.setFreqPWM(0, 100);
                    mGpioControl.setDuty(0, 300); //200부터 동작 (나옴)
                }
                else{
                    mGpioControl.setFreqPWM(0,100);
                    mGpioControl.setDuty(0, 100); //100부터 동작 (들어감)
                }

            }
        });


        //PWM }}}


        //{{{opencv
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //퍼미션 상태 확인
            if (!hasPermissions(PERMISSIONS)) {

                //퍼미션 허가 안되어있다면 사용자에게 요청
                requestPermissions(PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
        }

        mOpenCvCameraView = findViewById(R.id.activity_surface_view);
        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
        mOpenCvCameraView.setCvCameraViewListener(this);
        mOpenCvCameraView.setCameraIndex(0); // front-camera(1),  back-camera(0)
        mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
    }
    //opencv}}}
    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        //{{{opencv
        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "onResume :: Internal OpenCV library not found.");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_2_0, this, mLoaderCallback);
        } else {
            Log.d(TAG, "onResume :: OpenCV library found inside package. Using it!");
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
        //opencv}}}
    }
    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();


        mBtn_GPIO.setChecked(false);

        mBtn_PWM.setChecked(false);

//{{opencv
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
        //opencv}}}
    }

    //{{opencv
    public void onDestroy() {
        super.onDestroy();

        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }


    @Override
    public void onCameraViewStarted(int width, int height) {
        matInput = new Mat(height, width, CvType.CV_8UC4);
        matOutput = new Mat(height,width,CvType.CV_8UC4);

        //mByte= new Mat(height,width,CvType.CV_8SC4);
        mIntermediateMat = new Mat(height, width, CvType.CV_8UC4);
        mGray = new Mat(height, width, CvType.CV_8UC1);
        previous = new Mat(width, height, CvType.CV_64FC4);        //차프레임 구할때 쓰는 프레임 RESULT BUTTON
        current = new Mat(width, height, CvType.CV_64FC4);         //차프레임 구할때 쓰는 프레임 RESULT BUTTON
        difference = new Mat(width, height, CvType.CV_64FC4);
    }

    @Override
    public void onCameraViewStopped() {
        matInput.release();
        mGray.release();
        mIntermediateMat.release();
        current.release();
        previous.release();
        difference.release();
    }


//    private int[] red = new int[scale];
//    private int[] green = new int[scale];
//    private int[] blue = new int[scale];
//    private int[] gray = new int[scale];
    int startX = 0;
    int startY = 120;
    int Roi_height=20;
    int Roi_width=400;

    @Override
    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {
//{{{roi

        ROIhandler.postDelayed(mRunnableROI,1000);
        tv1= findViewById(R.id.ROI_1);
        tv2 = findViewById(R.id.ROI_2);
        tv3 = findViewById(R.id.ROI_3);
        tv4 = findViewById(R.id.ROI_4);
        tv5 = findViewById(R.id.ROI_5);
        tv6 = findViewById(R.id.ROI_6);
        tv7 = findViewById(R.id.ROI_7);
        tv8 = findViewById(R.id.ROI_8);
        tv9 = findViewById(R.id.ROI_9);
        tv10 =findViewById(R.id.ROI_10);
        int[][] pixeldata;
        //roi 색 설정
        Scalar color = new Scalar(255, 0, 0);
//        int distance = 40; //roi간의 간격

        //roi 시작 좌표, X,Y의 전체 크기는 아래서 구함.

        //test용 roibars
        //Rect[] roibars = new Rect[scale];

        //Roi 영역설정. startX , Y = 시작 위치 너비와 높이 설정.
        //Roi 영역이 화면 밖으로 넘어가게 되면 에러발생하면서 어플이 죽으니 주의.
        Rect Roi= new Rect(startX,startY,Roi_width,Roi_height);

        //test용.
        int scale = 10;
        int[][] avgRGB = new int[scale][4];

        //roi data 관련 함수들 모아놓은 클래스 객체화.
        roiDataExtract roiData= new roiDataExtract();

        //pixeldata = Roi영역의 각 픽셀에 해당하는 rgb값
        pixeldata=roiData.getPixeldata(Roi,matInput);

        //avgPixelData = 그래프로 표시하기 위해 height 평균시킴.
        avgPixelData=new int[400];
        avgPixelData=roiData.AvgPixeldata(Roi,pixeldata);


        try {

            matInput = inputFrame.rgba();

            //화면의 크기는 layout에서 설정한 것에 따라 다르므로 Log창에서 너비와 높이를 확인해야한다.
//            Log.i("MatInput height: ",Integer.toString(matInput.height()));
//            Log.i("MatInput width: ",Integer.toString(matInput.width()));

        }catch (Exception e){
            e.printStackTrace();
        }

        if (first) {
            first = false;
            return matInput;
        }

        Imgproc.rectangle(matInput, new Point(0, 110), new Point(432, 130), color, 1); //test용으로 출력 (지우면 처리속도 증가)

        return matInput;

    }
    //roi}}}


    //여기서부턴 퍼미션 관련 메소드
    static final int PERMISSIONS_REQUEST_CODE = 1000;
    String[] PERMISSIONS  = {"android.permission.CAMERA",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.INTERNET"};


    private boolean hasPermissions(String[] permissions) {
        int result;

        //스트링 배열에 있는 퍼미션들의 허가 상태 여부 확인
        for (String perms : permissions){

            result = ContextCompat.checkSelfPermission(this, perms);

            if (result == PackageManager.PERMISSION_DENIED){
                //허가 안된 퍼미션 발견
                return false;
            }
        }

        //모든 퍼미션이 허가되었음
        return true;
    }




    public void Roi_update(){
        tv1.setText(String.valueOf("#1 : "+avgPixelData[50]));
        tv2.setText(String.valueOf("#2 : "+avgPixelData[80]));
        tv3.setText(String.valueOf("#3 : "+avgPixelData[110]));
        tv4.setText(String.valueOf("#4 : "+avgPixelData[140]));
        tv5.setText(String.valueOf("#5 : "+avgPixelData[170]));
        tv6.setText(String.valueOf("#6 : "+avgPixelData[200]));
        tv7.setText(String.valueOf("#7 : "+avgPixelData[230]));
        tv8.setText(String.valueOf("#8 : "+avgPixelData[260]));
        tv9.setText(String.valueOf("#9 : "+avgPixelData[290]));
        tv10.setText(String.valueOf("#10: "+avgPixelData[320]));


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch(requestCode){

            case PERMISSIONS_REQUEST_CODE:
                if (grantResults.length > 0) {
                    boolean cameraPermissionAccepted = grantResults[0]
                            == PackageManager.PERMISSION_GRANTED;

                    if (!cameraPermissionAccepted)
                        showDialogForPermission("앱을 실행하려면 퍼미션을 허가하셔야합니다.");
                }
                break;
        }
    }
    @TargetApi(Build.VERSION_CODES.M)
    private void showDialogForPermission(String msg) {

        AlertDialog.Builder builder = new AlertDialog.Builder( MainActivity.this);
        builder.setTitle("알림");
        builder.setMessage(msg);
        builder.setCancelable(false);
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id){
                requestPermissions(PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                finish();
            }
        });
        builder.create().show();
    }
    //opencv}}}
    public native int wiringPiSetup();
    //    public native int wiringPiSetupSys();
    public native int analogRead(int port);
    public native void digitalWrite(int port, int onoff);
    public native void pinMode(int port, int value);
    public native void ConvertRGBtoGray(long matAddrInput, long matAddrResult);
}