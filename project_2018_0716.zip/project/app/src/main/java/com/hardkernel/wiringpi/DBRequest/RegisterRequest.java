package com.hardkernel.wiringpi.DBRequest;

import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ygyg331 on 2018-05-19.
 */

public class RegisterRequest extends StringRequest {

    final static private String URL = "http://ygyg331.cafe24.com/register.php.php";
    private Map<String, String> parameters;

    public RegisterRequest(String userID, String userPassword, String userName, int userAge, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);
        parameters = new HashMap<>();
        parameters.put("userID", userID);
        parameters.put("userPassword", userPassword);
        parameters.put("userName", userName);
        parameters.put("userAge", userAge + ""); //int형이므로 ""를 붙여야함.



    }

    @Override
    public Map<String, String> getParams() {
        return parameters;
    }
}