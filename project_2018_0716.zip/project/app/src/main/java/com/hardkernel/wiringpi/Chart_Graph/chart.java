package com.hardkernel.wiringpi.Chart_Graph;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.*;
import com.hardkernel.wiringpi.R;

import java.util.ArrayList;

/**
 * Created by ygyg331 on 2018-06-28.
 */
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarChart;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.SeriesSelection;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import java.util.Random;

public class chart extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chart);
        Intent get = getIntent();

        int[] data= get.getIntArrayExtra("avgpixel");
        Log.i("data : ",Integer.toString(data[10]));

        //갯수 추가를 위해서는
        //dataset에 있는 xySeries의 수와 renderer에 있는 xySeriesRender의 수가 맞아야함



        //그래프 생성
        final GraphicalView chart = ChartFactory.getLineChartView(this, getDataset(data), getRenderer());
        //레이아웃에 추가
        LinearLayout layout = (LinearLayout) findViewById(R.id.chart);
        layout.addView(chart);


    }

    //그래프 설정 모음
    // http://www.programkr.com/blog/MQDN0ADMwYT3.html ( 그래프 설정 속성 한글로 써져있는 사이트 )
    private void setChartSettings(XYMultipleSeriesRenderer renderer) {
        //타이틀, x,y축 글자
        renderer.setChartTitle("Chart demo");
        renderer.setXTitle("width of Roi");

        renderer.setXLabelsColor(Color.BLACK);
        renderer.setYLabelsColor(0,Color.BLACK);
        renderer.setYTitle("RGB range");

        renderer.setRange(new double[] {0,6,-70,40});


        //background
        renderer.setApplyBackgroundColor(true);      //변경 가능여부
        renderer.setBackgroundColor(Color.WHITE);    //그래프 부분 색
        renderer.setMarginsColor(Color.WHITE);       //그래프 바깥 부분 색(margin)

        //글자크기
        renderer.setAxisTitleTextSize(15);          //x,y축 title
        renderer.setChartTitleTextSize(20);         //상단 title
        renderer.setLabelsTextSize(15);             //x,y축 수치
        renderer.setLegendTextSize(15);             //Series 구별 글씨 크기
        renderer.setPointSize(10f);
        renderer.setMargins(new int[] { 20, 20, 50, 50 }); //상 좌 하 우 ( '하' 의 경우 setFitLegend(true)일 때에만 가능 )

        //색
        renderer.setAxesColor(Color.RED);       //x,y축 선 색
        renderer.setLabelsColor(Color.CYAN);    //x,y축 글자색

        //x,y축 표시 간격 ( 각 축의 범위에 따라 나눌 수 있는 최소치가 제한 됨 )
        renderer.setXLabels(50);
        renderer.setYLabels(50);

        //x축 최대 최소(화면에 보여질)
        renderer.setXAxisMin(0);
        renderer.setXAxisMax(400);
        //y축 최대 최소(화면에 보여질)
        renderer.setYAxisMin(0);
        renderer.setYAxisMax(255);

        //클릭 가능 여부
        renderer.setClickEnabled(true);
        //줌 기능 가능 여부
        renderer.setZoomEnabled(false,false);
        //X,Y축 스크롤
        renderer.setPanEnabled(true, false);                // 가능 여부
        renderer.setPanLimits(new double[]{-2,24,20,40} );   // 가능한 범위

        //지정된 크기에 맞게 그래프를 키움
        renderer.setFitLegend(true);
        //간격에 격자 보이기
        renderer.setShowGrid(true);
//
        renderer.setDisplayValues(true);
    }

    //선 그리기
    private XYMultipleSeriesRenderer getRenderer() {
        XYMultipleSeriesRenderer renderer = new XYMultipleSeriesRenderer();

        //---그려지는 점과 선 설정----
        XYSeriesRenderer r = new XYSeriesRenderer();
        r.setColor(Color.BLACK);            //색
        r.setPointStyle(PointStyle.POINT);//점의 모양
        r.setFillPoints(false);             //점 체우기 여부
        renderer.addSeriesRenderer(r);
        //----------------------------

        /*
        * 다른 그래프를 추가하고 싶으면
        * XYSeriesRenderer 추가로 생성한 후
        *  renderer.addSeriesRenderer(r) 해준다 (Data도 있어야함)
        *
        */


        setChartSettings(renderer);
        return renderer;
    }

    //데이터들
    private XYMultipleSeriesDataset getDataset( int[] data ) {
        XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();


        XYSeries series = new XYSeries("평균RGB value");
        for (int i = 0; i < data.length; i++ ) {
            series.add(i, data[i] );
        }

        /*
        *
        * 다른 그래프를 추가하고 싶으면
        * XYSeries를 추가로 생성한 후
        * dataset.addSeries(series) 해준다 (renderer도 있어야함)
        *
        */


        dataset.addSeries(series);


        return dataset;
    }

}

