package com.hardkernel.wiringpi.GPIO;

import android.util.Log;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static android.content.ContentValues.TAG;

/**
 * Created by ygyg331 on 2018-07-03.
 */


public class GpioControl {

    private ToggleButton mBtn_PWM;
    private Switch mswitch;
    private int mPWMCount = 1;
    private final String PWM_PREFIX = "/sys/devices/pwm-ctrl.";
    private final String PWM_ENABLE = "/enable";
    private final String PWM_DUTY = "/duty";
    private final String PWM_FREQ = "/freq"; //added J.
    private String mPWMEnableNode;
    private String mPWMDutyNode;
    private String mPWMFreqNode; //added J.
    private Process mProcess;

    public void init(){
        try {
            mProcess = Runtime.getRuntime().exec("su");
            for (int i = 0; i < 100; i++) {
                File f = new File(PWM_PREFIX + i);
                if (f.isDirectory()) {
                    mPWMEnableNode = PWM_PREFIX + i + PWM_ENABLE;
                    Log.e(TAG, "pwm enable : " + mPWMEnableNode);
                    mPWMDutyNode = PWM_PREFIX + i + PWM_DUTY;
                    Log.e(TAG, "pwm duty : " + mPWMDutyNode);
                    mPWMFreqNode = PWM_PREFIX + i + PWM_FREQ; //added J.
                    break;
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void insmodPWM() {
        try {
            DataOutputStream os = new DataOutputStream(mProcess.getOutputStream());
            os.writeBytes("insmod /system/lib/modules/pwm-meson.ko\n");
            os.writeBytes("insmod /system/lib/modules/pwm-ctrl.ko\n");
            os.flush();
            Thread.sleep(100);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void rmmodPWM() {
        try {
            DataOutputStream os = new DataOutputStream(mProcess.getOutputStream());
            os.writeBytes("rmmod pwm_ctrl\n");
            os.writeBytes("rmmod pwm_meson\n");
            os.flush();
            Thread.sleep(100);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void setEnalbePWM(int index, boolean enable) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(mPWMEnableNode + index));
            if (enable)
                bw.write("1");
            else
                bw.write("0");
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //added J.
    //need to set the frequency
    public void setFreqPWM(int index,int value){
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(mPWMFreqNode + index));
            bw.write(Integer.toString(value));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setDuty(int index, int duty) {
        try {
            //                mPWMDutyNode = PWM_PREFIX + i + PWM_DUTY;
            // /sys/devices/pwm-ctrl.43/duty
            BufferedWriter bw = new BufferedWriter(new FileWriter(mPWMDutyNode + index));
            bw.write(Integer.toString(duty));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //PWM }}}


}
