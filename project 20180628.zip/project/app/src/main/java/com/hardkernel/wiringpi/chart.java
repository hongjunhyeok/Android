package com.hardkernel.wiringpi;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.*;

import java.util.ArrayList;

/**
 * Created by ygyg331 on 2018-06-28.
 */


public class chart extends AppCompatActivity {
    LineChart chart;
    int X_RANGE = 400;
    int Data_range = 255;

    ArrayList<Entry> xVal;
    LineDataSet setXcomp;
    ArrayList<String>xVals;
    ArrayList<LineDataSet> lineDataSets;
    LineData lineData;


     Intent intent = getIntent();
     int[] pixeldata = intent.getIntArrayExtra("pixel");


    @Override
    protected  void  onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chart);
        init();
        threadStart();
    }

    private  void init(){
        chart = (LineChart) findViewById(R.id.chart);
        chartInit();
    }

    private  void chartInit(){
        chart.setAutoScaleMinMaxEnabled(true);
        xVal = new ArrayList<Entry>();
        setXcomp = new LineDataSet(xVal,"X");
        setXcomp.setColor(Color.GREEN);
        setXcomp.setDrawValues(false);
        setXcomp.setDrawCircles(false);
        setXcomp.setAxisDependency(YAxis.AxisDependency.LEFT);
        lineDataSets = new ArrayList<LineDataSet>();
        lineDataSets.add(setXcomp);

        xVals = new ArrayList<>();
        for(int i=0;i<X_RANGE;i++){
            xVals.add("");
        }
        lineData = new LineData(xVals,lineDataSets);
        chart.setData(lineData);
        chart.invalidate();

    }
    public void chartUpdate(int x){
        if(xVal.size() > Data_range){
            xVal.remove(0);
            for(int i=0;i<Data_range;i++){
                xVal.get(i).setXIndex(i);
            }
        }
        xVal.add(new Entry(x,xVal.size()));
        setXcomp.notifyDataSetChanged();
        chart.notifyDataSetChanged();
        chart.invalidate();
    }


    Handler handler = new Handler(){
        @Override
        public  void handleMessage(Message msg){
            if(msg.what == 0){
                int a=0;

                a= (int)(Math.random()*100);
                chartUpdate(a);
            }
        }
    };
    class Mythread extends Thread{
        @Override
        public void run(){
            while(true){
                handler.sendEmptyMessage(0);
                try{
                    Thread.sleep(50);

                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
    }
    private void threadStart(){
        Mythread mythread = new Mythread();
        mythread.setDaemon(true);
        mythread.start();
    }
}
