package com.hardkernel.wiringpi;

import android.app.Activity;
import android.content.Intent;

import org.opencv.core.Mat;
import org.opencv.core.Rect;

/**
 * Created by ygyg331 on 2018-06-28.
 */

public class roiDataExtract {
    public int[][] getPixeldata(Rect Roi, Mat matInput){
        int avg1=0,avg2=0,avg3=0,avg4=0;
        int pixels[][]=new int[Roi.width][Roi.height];

        for(int i = Roi.x; i< Roi.x+Roi.width ;i++)
            for(int j = Roi.y; j<Roi.y+Roi.height;j++)
            {
                double[] rgbV = matInput.get(j, i);
                avg1 = (int)( (rgbV[0]+rgbV[1]+rgbV[2])/3);
                pixels[i-Roi.x][j-Roi.y]=avg1;
            }
        return pixels;
    }
}
